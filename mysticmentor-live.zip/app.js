/**
 * MysticMentor Live - System Orchestration (app.js)
 * File: /app.js
 * 
 * Manages:
 * 1. Global state initialization.
 * 2. Tarot deck Fisher-Yates shuffling.
 * 3. Event bindings for the UI (including Reset Session).
 */

const MysticApp = {
  // Initialize all subsystems
  init() {
    console.log("System Initializing: MysticMentor Live...");
    
    // Brand & Audio init automatically on load via their modules, 
    // but ensure listeners are bound here
    this.bindEvents();
  },

  /**
   * Fisher-Yates Shuffle Algorithm for the Tarot Deck
   */
  shuffleDeck(deck) {
    for (let i = deck.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [deck[i], deck[j]] = [deck[j], deck[i]];
    }
    return deck;
  },

  /**
   * Master Session Reset Action
   */
  resetSession() {
    console.log("System Status: Resetting Session...");
    
    // 1. Wipe Notes
    const notesArea = document.querySelector('textarea');
    if (notesArea) notesArea.value = '';
    
    // 2. Wipe Queue
    const queueList = document.getElementById('queue-list');
    if (queueList) queueList.innerHTML = '';
    
    // 3. Reset Canvas (if rendered)
    const canvas = document.getElementById('room-container');
    if (canvas) canvas.innerHTML = '<p class="text-white/50 text-center mt-10">Canvas Cleared.</p>';
    
    // 4. Stop all ambient audio
    if (window.MysticAudioEngine) {
      window.MysticAudioEngine.stopAll();
    }
    
    alert("Session Swept Clear. Ready for new stream.");
  },

  /**
   * Bind DOM Events
   */
  bindEvents() {
    const resetButton = document.getElementById('reset-session');
    if (resetButton) {
      resetButton.addEventListener('click', () => this.resetSession());
    }
  }
};

// Start the Application
document.addEventListener('DOMContentLoaded', () => {
  MysticApp.init();
});
