/**
 * MysticMentor Live - Comprehensive Tarot & Reiki Dataset (src/data.js)
 * Updated Schema: MysticDeckData
 */

export const MysticDeckData = {
  // 1. Comprehensive Tarot Deck Data Matrix
  tarotDeck: [
    {
      id: "major-0",
      name: "The Fool",
      type: "Major",
      suit: "None",
      upright: "New beginnings, spontaneous actions, innocence, leap of faith.",
      reversed: "Recklessness, risk-taking, holding back, fear of the unknown.",
      mediumshipAdvice: "A spirit guide is signaling a clean slate. Tell the viewer to release past trauma; an ancestor who passed suddenly is urging them to take that leap of faith without looking back.",
      image: "assets/cards/major_0.jpg"
    },
    {
      id: "major-1",
      name: "The Magician",
      type: "Major",
      suit: "None",
      upright: "Manifestation, willpower, resourcefulness, absolute capability.",
      reversed: "Illusion, manipulation, wasted talent, untapped latent potential.",
      mediumshipAdvice: "The energy around the viewer reveals strong ancestral spiritual gifts. A maternal ancestor is confirming that they have all the tools necessary to heal their current situation.",
      image: "assets/cards/major_1.jpg"
    },
    {
      id: "major-2",
      name: "The High Priestess",
      type: "Major",
      suit: "None",
      upright: "Intuition, sacred knowledge, divine feminine, subconscious mind.",
      reversed: "Secrets, disconnected from intuition, surface-level focus, repressed feelings.",
      mediumshipAdvice: "Strong spirit connection detected around gut instincts. Advise the viewer to pay attention to dreams and subtle synchronicities happening over the next 3 days.",
      image: "assets/cards/major_2.jpg"
    },
    {
      id: "major-3",
      name: "The Empress",
      type: "Major",
      suit: "None",
      upright: "Femininity, beauty, nature, nurturing, abundance, creation.",
      reversed: "Creative block, dependence, smothering, insecurity, disharmony.",
      mediumshipAdvice: "Maternal ancestral presence felt. Focus on themes of self-worth, emotional nurturing, and physical environment upgrades to welcome abundance.",
      image: "assets/cards/major_3.jpg"
    },
    {
      id: "major-4",
      name: "The Emperor",
      type: "Major",
      suit: "None",
      upright: "Authority, structure, foundation, control, leadership, stability.",
      reversed: "Tyranny, rigidity, lack of discipline, conflict with authority, chaos.",
      mediumshipAdvice: "Paternal ancestor energy stepping forward. Advise setting strict boundaries in business or family. Order and clear structure are needed right now.",
      image: "assets/cards/major_4.jpg"
    },
    {
      id: "major-5",
      name: "The Hierophant",
      type: "Major",
      suit: "None",
      upright: "Spiritual wisdom, tradition, institutions, belief systems, mentorship.",
      reversed: "Rebellion, personal beliefs, unconventional path, challenging dogma.",
      mediumshipAdvice: "Spirit guides suggest breaking away from outdated family or religious expectations. Encourage honoring personal truth over societal pressure.",
      image: "assets/cards/major_5.jpg"
    },
    {
      id: "major-6",
      name: "The Lovers",
      type: "Major",
      suit: "None",
      upright: "Love, harmony, relationships, values alignment, choices.",
      reversed: "Self-love deficiency, disharmony, misalignment of values, indecision.",
      mediumshipAdvice: "Highlight choice and soul alignment. If asking about a partner, mediumship suggests evaluating if this person elevates their spiritual frequency or drains it.",
      image: "assets/cards/major_6.jpg"
    },
    {
      id: "major-7",
      name: "The Chariot",
      type: "Major",
      suit: "None",
      upright: "Control, willpower, success, determination, direction, drive.",
      reversed: "Lack of control, directionless, opposition, aggression, feeling stuck.",
      mediumshipAdvice: "High kinetic spirit energy! The viewer is being urged to pull opposing forces together and take charge of their momentum. Triumph is guaranteed through focus.",
      image: "assets/cards/major_7.jpg"
    },
    {
      id: "major-8",
      name: "Strength",
      type: "Major",
      suit: "None",
      upright: "Courage, compassion, patience, inner power, soft control.",
      reversed: "Self-doubt, weakness, raw emotion, vulnerability, impatience.",
      mediumshipAdvice: "Channel gentle resilience. An ancestor who endured heavy hardships reassures the viewer that quiet compassion will win over harsh confrontation.",
      image: "assets/cards/major_8.jpg"
    },
    {
      id: "major-9",
      name: "The Hermit",
      type: "Major",
      suit: "None",
      upright: "Soul-searching, introspection, solitude, inner guidance, wisdom.",
      reversed: "Loneliness, isolation, paranoia, withdrawal, ignoring wisdom.",
      mediumshipAdvice: "Time for a temporary digital retreat. Suggest taking 24 hours away from noise to hear their internal voice and guides clearly.",
      image: "assets/cards/major_9.jpg"
    },
    {
      id: "major-10",
      name: "Wheel of Fortune",
      type: "Major",
      suit: "None",
      upright: "Good luck, destiny, change, karma, cycles, decisive turning point.",
      reversed: "Bad luck, resistance to change, breaking negative cycles, setbacks.",
      mediumshipAdvice: "Karmic turning point! Remind the live audience that life operates in seasonal shifts; a difficult cycle is ending to make room for unexpected luck.",
      image: "assets/cards/major_10.jpg"
    },
    {
      id: "major-11",
      name: "Justice",
      type: "Major",
      suit: "None",
      upright: "Fairness, truth, cause and effect, law, accountability, clarity.",
      reversed: "Unfairness, lack of accountability, dishonesty, karmic imbalance.",
      mediumshipAdvice: "Legal, contractual, or ethical resolution incoming. Channel truth and integrity: what was done in secret will come into the light for fair resolution.",
      image: "assets/cards/major_11.jpg"
    },
    {
      id: "major-12",
      name: "The Hanged Man",
      type: "Major",
      suit: "None",
      upright: "Pause, surrender, letting go, new perspective, spiritual enlightenment.",
      reversed: "Stalling, needless sacrifice, resistance, martyrdom, standstill.",
      mediumshipAdvice: "The universe has put things on hold for a reason. Tell the viewer to surrender to the waiting period—insight comes from looking at the situation upside down.",
      image: "assets/cards/major_12.jpg"
    },
    {
      id: "major-13",
      name: "Death",
      type: "Major",
      suit: "None",
      upright: "Endings, transformation, transition, letting go of the old, rebirth.",
      reversed: "Resistance to change, holding on to decay, fear of rebirth, stagnation.",
      mediumshipAdvice: "Do not fear this card! Ancestor guidance points to shedding an old identity or job. You cannot step into your next chapter while holding onto the dead weight.",
      image: "assets/cards/major_13.jpg"
    },
    {
      id: "major-14",
      name: "Temperance",
      type: "Major",
      suit: "None",
      upright: "Balance, moderation, patience, purpose, alchemy, peace.",
      reversed: "Imbalance, excess, extreme behavior, lack of patience, disharmony.",
      mediumshipAdvice: "Angelic energy presence. Advise blending different aspects of life gently rather than taking extreme binary actions. Patience is key.",
      image: "assets/cards/major_14.jpg"
    },
    {
      id: "major-15",
      name: "The Devil",
      type: "Major",
      suit: "None",
      upright: "Shadow self, attachment, addiction, restriction, illusion of helplessness.",
      reversed: "Freedom, releasing limiting beliefs, breaking chains, reclaiming power.",
      mediumshipAdvice: "Identify toxic attachments or codependency. Remind the viewer that the chains around their neck are loose—they hold the key to walk away anytime.",
      image: "assets/cards/major_15.jpg"
    },
    {
      id: "major-16",
      name: "The Tower",
      type: "Major",
      suit: "None",
      upright: "Sudden upheaval, revelation, awakening, breaking illusions, breakthrough.",
      reversed: "Averting disaster, delaying the inevitable, fear of radical truth.",
      mediumshipAdvice: "An intense message regarding an abrupt structural change. Grounding energy is needed right now; tell the viewer that a chaotic event was actually an intervention by their protectors.",
      image: "assets/cards/major_16.jpg"
    },
    {
      id: "major-17",
      name: "The Star",
      type: "Major",
      suit: "None",
      upright: "Hope, faith, renewal, inspiration, serenity, cosmic blessing.",
      reversed: "Faithlessness, despair, discouragement, feeling hopeless, negativity.",
      mediumshipAdvice: "Healing frequency stream! Spirit guides send a wave of peaceful assurance. A long-held wish or recovery phase is currently unfolding.",
      image: "assets/cards/major_17.jpg"
    },
    {
      id: "major-18",
      name: "The Moon",
      type: "Major",
      suit: "None",
      upright: "Illusion, fear, anxiety, intuition, subconscious secrets, veiled truth.",
      reversed: "Release of fear, unveiling secrets, clarity, overcoming anxiety.",
      mediumshipAdvice: "Things are not as they appear on the surface. Tell the viewer to trust psychic impressions over physical appearance. Deep subconscious healing taking place.",
      image: "assets/cards/major_18.jpg"
    },
    {
      id: "major-19",
      name: "The Sun",
      type: "Major",
      suit: "None",
      upright: "Joy, success, warmth, vitality, truth, radiance, celebration.",
      reversed: "Temporary cloudiness, muted joy, overly optimistic, need for playfulness.",
      mediumshipAdvice: "Radiant light energy! Celebrate upcoming success, physical vitality, and authentic self-expression. A green light from spirit across all boards.",
      image: "assets/cards/major_19.jpg"
    },
    {
      id: "major-20",
      name: "Judgement",
      type: "Major",
      suit: "None",
      upright: "Rebirth, inner calling, absolution, awakening, reckoning, purpose.",
      reversed: "Self-doubt, harsh judgment, ignoring the call, regret, stagnation.",
      mediumshipAdvice: "Soul call sound! Spirit is summoning the viewer to step into a higher calling. Forgive past mistakes and step up to your divine purpose.",
      image: "assets/cards/major_20.jpg"
    },
    {
      id: "major-21",
      name: "The World",
      type: "Major",
      suit: "None",
      upright: "Completion, integration, accomplishment, travel, fulfillment, wholeness.",
      reversed: "Incomplete goals, lack of closure, shortcuts, delayed completion.",
      mediumshipAdvice: "Master cycle completion! A major life lesson or long-term project has reached full fruition. Celebrate before opening the next door.",
      image: "assets/cards/major_21.jpg"
    }
  ],

  // 2. The Comprehensive 12-Position Reiki Hand Placement Matrix
  reikiMatrix: {
    precepts: [
      "Just for today, I will not be angry.",
      "Just for today, I will not worry.",
      "Just for today, I will be grateful.",
      "Just for today, I will do my work honestly.",
      "Just for today, I will be kind to every living thing."
    ],
    handPositions: [
      {
        positionId: "head-1",
        name: "Eyes and Face",
        focus: "Third Eye and Crown Chakras",
        intention: "To bring deep mental clarity, soothe overall stress, relieve sinus pressure, and calm a racing mind before conducting readings."
      },
      {
        positionId: "head-2",
        name: "Sides of the Head",
        focus: "Brain Hemispheres Alignment",
        intention: "To balance the left and right intuitive channels, quiet analytical thinking, and open up clear clairsentient listening channels."
      },
      {
        positionId: "head-3",
        name: "Occipital Base",
        focus: "Brainstem & Survival Center",
        intention: "To release deep subconscious fears, soothe the nervous system, and ground the practitioner."
      },
      {
        positionId: "throat-1",
        name: "Throat and Neck",
        focus: "Throat Chakra",
        intention: "To open authentic communication lines, clear out unexpressed blocks, and empower the voice to speak hard ancestral truths accurately during live streams."
      },
      {
        positionId: "heart-1",
        name: "Heart Center",
        focus: "Heart Chakra",
        intention: "To anchor unconditional love, clear deep emotional grief, and establish a profound spiritual protection barrier for both reader and viewer."
      },
      {
        positionId: "solar-1",
        name: "Solar Plexus",
        focus: "Personal Power Center",
        intention: "To boost self-confidence, release gut-level anxiety, and restore personal authority."
      },
      {
        positionId: "sacral-1",
        name: "Sacral Area",
        focus: "Creative & Emotional Center",
        intention: "To unlock creativity, balance emotional flow, and heal relational blockages."
      },
      {
        positionId: "root-1",
        name: "Root Area",
        focus: "Grounding Center",
        intention: "To provide essential physical safety, ground high-frequency energy, and alleviate financial/survival anxieties."
      },
      {
        positionId: "back-1",
        name: "Upper Back",
        focus: "Trapezius/Responsibility",
        intention: "To release the weight of burdens carried for others and soothe shoulder tension."
      },
      {
        positionId: "back-2",
        name: "Kidney/Adrenal Area",
        focus: "Vitality Center",
        intention: "To replenish depleted adrenal reserves and soothe fight-or-flight nervous fatigue."
      },
      {
        positionId: "knee-1",
        name: "Knees",
        focus: "Flexibility Center",
        intention: "To foster flexibility in life transitions and release stubborn pride."
      },
      {
        positionId: "foot-1",
        name: "Soles of the Feet",
        focus: "Earth Connection",
        intention: "To complete the grounding process and anchor higher spiritual energy into physical reality."
      }
    ]
  }
};
