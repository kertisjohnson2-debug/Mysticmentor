/**
 * MysticMentor Live - Multi-Track Ambient Audio Engine
 * File: /audio.js
 * 
 * Manages:
 * 1. Independent HTML5 Audio loopable tracks (Deep Meditation Singing Bowls, 
 *    Ethereal Pad Synths, Cosmic Binaural Waves, Soft Shamanic Drums).
 * 2. Individual track volume scaling.
 * 3. Master volume control scaling across all tracks.
 * 4. Global Play/Pause toggles.
 */

const MysticAudioEngine = {
  // Track Registry & Initial Volumes
  tracks: {
    'singing-bowls': { 
      name: 'Deep Meditation Singing Bowls',
      audio: new Audio('https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3'), 
      volume: 0.5 
    },
    'pad-synths': { 
      name: 'Ethereal Pad Synths',
      audio: new Audio('https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3'), 
      volume: 0.5 
    },
    'binaural-waves': { 
      name: 'Cosmic Binaural Waves',
      audio: new Audio('https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3'), 
      volume: 0.5 
    },
    'shamanic-drums': { 
      name: 'Soft Shamanic Drums',
      audio: new Audio('https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3'), 
      volume: 0.5 
    }
  },
  
  masterVolume: 1.0,

  /**
   * Initialization: Set up looping and prep for playback
   */
  init() {
    Object.values(this.tracks).forEach(track => {
      track.audio.loop = true;
      track.audio.volume = track.volume * this.masterVolume;
    });
  },

  /**
   * Set volume for a specific track (0.0 to 1.0)
   */
  setTrackVolume(trackId, volume) {
    if (this.tracks[trackId]) {
      this.tracks[trackId].volume = Math.max(0, Math.min(1, volume));
      this.tracks[trackId].audio.volume = this.tracks[trackId].volume * this.masterVolume;
    }
  },

  /**
   * Set Master volume (0.0 to 1.0) - scales all tracks proportionally
   */
  setMasterVolume(volume) {
    this.masterVolume = Math.max(0, Math.min(1, volume));
    Object.values(this.tracks).forEach(track => {
      track.audio.volume = track.volume * this.masterVolume;
    });
  },

  /**
   * Toggle playback for a track
   */
  toggleTrack(trackId) {
    const track = this.tracks[trackId];
    if (track) {
      if (track.audio.paused) {
        track.audio.play().catch(e => console.error("Audio playback error:", e));
      } else {
        track.audio.pause();
      }
    }
  }
};

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  MysticAudioEngine.init();
});

// Attach to window for global access
window.MysticAudioEngine = MysticAudioEngine;
