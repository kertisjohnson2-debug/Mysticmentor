/**
 * MysticMentor Live - Persistent Custom Branding Engine
 * File: /brand.js
 * 
 * Manages: 
 * 1. Background profile styles (mapped to CSS body classes).
 * 2. Neon highlight accent colors (synced via CSS variables).
 * 3. LocalStorage persistence for user layout locks.
 * 4. Dynamic typing indicator dot color & glow synchronization.
 */

const MysticBrandState = {
  // Current State
  activeTheme: 'nebula-swirl',
  activeNeonColor: '#ff00ff', // Default Neon Pink

  // Available Styles
  themes: {
    'nebula-swirl': 'theme-nebula',
    'cosmic-dust': 'theme-dust',
    'aurora-gradient': 'theme-aurora',
    'deep-space-void': 'theme-void'
  },

  /**
   * Load state from localStorage on init
   */
  init() {
    const stored = localStorage.getItem('MysticMentor_Brand');
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        this.activeTheme = parsed.theme || this.activeTheme;
        this.activeNeonColor = parsed.color || this.activeNeonColor;
      } catch (e) {
        console.error("Branding initialization error:", e);
      }
    }
    this.apply();
  },

  /**
   * Save state to localStorage to persist user layout preferences
   */
  save() {
    localStorage.setItem('MysticMentor_Brand', JSON.stringify({
      theme: this.activeTheme,
      color: this.activeNeonColor
    }));
  },

  /**
   * Apply all styles to DOM: classnames, CSS variables, and typing indicator
   */
  apply() {
    // 1. Update Body Theme Class
    document.body.className = this.themes[this.activeTheme] || 'theme-nebula';

    // 2. Update CSS Variable for global neon accent
    document.documentElement.style.setProperty('--neon-accent', this.activeNeonColor);

    // 3. Update Typing Indicator
    this.updateIndicator();
  },

  /**
   * Manually sync the blinking typing indicator dot
   */
  updateIndicator() {
    const indicator = document.getElementById('typing-indicator-dot');
    if (indicator) {
      // Set indicator color
      indicator.style.backgroundColor = this.activeNeonColor;
      // Set indicator glow based on color
      indicator.style.boxShadow = `0 0 10px ${this.activeNeonColor}, 0 0 20px ${this.activeNeonColor}`;
    }
  },

  /**
   * Public API: Set Theme
   */
  setTheme(themeId) {
    if (this.themes[themeId]) {
      this.activeTheme = themeId;
      this.apply();
      this.save();
    }
  },

  /**
   * Public API: Set Accent Color
   */
  setAccentColor(hexCode) {
    this.activeNeonColor = hexCode;
    this.apply();
    this.save();
  }
};

// Initialize when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  MysticBrandState.init();
});

// Expose to window for global access
window.MysticBrandState = MysticBrandState;
