/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface TarotCard {
  id: number;
  name: string;
  number: string;
  iconName: string; // Used to select Lucide icons dynamically
  uprightKeywords: string[];
  reversedKeywords: string[];
  uprightMeaning: string;
  reversedMeaning: string;
  description: string;
  advice: string;
  isHidden?: boolean; // Admin visibility toggle support
}

export interface ZodiacSign {
  id: string;
  name: string;
  symbol: string;
  dateRange: string;
  element: "Fire" | "Earth" | "Air" | "Water";
  rulingPlanet: string;
  traits: string[];
  compatibility: string;
  luckyColor: string;
  horoscope: {
    general: string;
    love: string;
    career: string;
    luckyNumber: number;
    luckyTime: string;
    mood: string;
  };
}

export interface NumerologyProfile {
  number: number;
  title: string;
  tagline: string;
  personality: string;
  strengths: string[];
  weaknesses: string[];
  careerPaths: string[];
  compatibility: string;
}

// 22 Detailed Major Arcana Cards
const MAJOR_ARCANA: TarotCard[] = [
  {
    id: 0,
    name: "The Fool",
    number: "0",
    iconName: "Compass",
    uprightKeywords: ["Beginnings", "Freedom", "Spontaneity", "Faith"],
    reversedKeywords: ["Recklessness", "Risk-taking", "Inconsiderate", "Disorder"],
    uprightMeaning: "A symbol of new beginnings, adventures, and clean slates. You are being called to take a leap of faith into the unknown, trusting that the universe will guide your steps.",
    reversedMeaning: "Warning of reckless choices, being naive, or holding back due to fear. You might be acting impulsively without looking at the consequences, or avoiding an exciting new path.",
    description: "A young traveler stands on the edge of a cliff, looking up to the sky with infinite hope, accompanied by a faithful canine companion.",
    advice: "Embrace spontaneity and let go of overthinking. Sometimes, the heart knows the path before the mind can map it out."
  },
  {
    id: 1,
    name: "The Magician",
    number: "I",
    iconName: "Wand2",
    uprightKeywords: ["Manifestation", "Willpower", "Resourceful", "Skill"],
    reversedKeywords: ["Manipulation", "Illusions", "Wasted talent", "Deception"],
    uprightMeaning: "You possess all the tools, skills, and energy required to manifest your deepest desires. Align your willpower with action to turn thoughts into absolute physical reality.",
    reversedMeaning: "Indicates that you may be misusing your power, manipulating situations, or feeling stuck despite having the talent to succeed. Watch out for illusions.",
    description: "Standing before an altar piled with symbols of all tarot suits, a figure points one hand to heaven and the other to earth, channeling cosmic forces.",
    advice: "Focus your intent and take action. The universe is waiting for your signal; do not let your talents lay dormant."
  },
  {
    id: 2,
    name: "The High Priestess",
    number: "II",
    iconName: "Moon",
    uprightKeywords: ["Intuition", "Sacred knowledge", "Subconscious", "Divine feminine"],
    reversedKeywords: ["Secrets", "Ignored intuition", "Surface-level", "Hidden motives"],
    uprightMeaning: "Trust your inner voice. This is a time for quiet reflection, dreams, and tapping into your subconscious wisdom. The answers you seek lie within, not in the external world.",
    reversedMeaning: "You are ignoring your gut feelings, listening to too much external noise, or dealing with hidden secrets that are starting to surface. Slow down and listen.",
    description: "Sitting between two pillars of light and shadow, wearing a crescent crown, she holds a scroll of sacred law.",
    advice: "Meditation and silence will serve you better than aggressive actions today. Let the mysteries unfold in their own time."
  },
  {
    id: 3,
    name: "The Empress",
    number: "III",
    iconName: "Crown",
    uprightKeywords: ["Abundance", "Creativity", "Fertility", "Nature"],
    reversedKeywords: ["Creative block", "Dependence", "Smothering", "Lack of growth"],
    uprightMeaning: "The ultimate card of nurture, creativity, and luxury. You are entering a period of abundant growth, beautiful artistic expression, and strong connection to nature and sensuality.",
    reversedMeaning: "Points to a block in your creative energy, feelings of codependency, or neglecting your self-care. You may be pouring too much into others and draining yourself.",
    description: "A majestic queen sits in a field of golden wheat, surrounded by luxury forests and streams, wearing a crown of stars.",
    advice: "Treat yourself with kindness and ground yourself in nature. Create something beautiful today without worrying about perfection."
  },
  {
    id: 4,
    name: "The Emperor",
    number: "IV",
    iconName: "Shield",
    uprightKeywords: ["Authority", "Structure", "Solid foundation", "Protection"],
    reversedKeywords: ["Rigidity", "Control freak", "Inefficiency", "Weakness"],
    uprightMeaning: "Establish order, structure, and solid boundaries. You are in a position of authority and must act with discipline, logic, and protective strength to secure your goals.",
    reversedMeaning: "Reflects an overbearing attitude, rigid control that suffocates progress, or a complete lack of discipline that is causing chaos in your environment.",
    description: "An elder ruler sits on a massive stone throne carved with rams' heads, holding an imperial scepter under a fiery sky.",
    advice: "Create a structured plan and stick to it. Discipline is not a restriction, but the scaffold of your eventual freedom."
  },
  {
    id: 5,
    name: "The Hierophant",
    number: "V",
    iconName: "BookOpen",
    uprightKeywords: ["Spiritual wisdom", "Tradition", "Institutions", "Mentorship"],
    reversedKeywords: ["Rebellion", "Unconventional", "Dogma", "New paths"],
    uprightMeaning: "Seeking spiritual guidance, traditional wisdom, or structured learning. It is a time to honor helpful customs, seek mentors, and study established systems of knowledge.",
    reversedMeaning: "A powerful sign of rebellion, questioning old paradigms, and forging your own highly personal, unconventional spiritual path away from rigid dogma.",
    description: "A sacred teacher raises two fingers in blessing over acolytes, seated before tall temple columns with keys of wisdom at his feet.",
    advice: "Learn the rules thoroughly before you seek to break them. There is timeless value in structure, but your soul must remain free."
  },
  {
    id: 6,
    name: "The Lovers",
    number: "VI",
    iconName: "Heart",
    uprightKeywords: ["Harmony", "Relationships", "Alignment", "Choices"],
    reversedKeywords: ["Disharmony", "Misalignment", "Inner conflict", "Bad choices"],
    uprightMeaning: "Represents deep connection, shared values, and major choices regarding relationships. It signals a beautiful alignment of mind, body, and soul with a person or path.",
    reversedMeaning: "Indicates a period of disharmony, self-doubt, or misalignment with a partner. You may be facing a difficult choice where your values are in conflict.",
    description: "Two figures stand blessed by an angel in an abundant garden, a fiery tree of knowledge rising in the background.",
    advice: "Ensure your choices align with your true core values rather than seeking temporary convenience or superficial approval."
  },
  {
    id: 7,
    name: "The Chariot",
    number: "VII",
    iconName: "Sparkles",
    uprightKeywords: ["Willpower", "Victory", "Determination", "Control"],
    reversedKeywords: ["Lack of control", "Aggression", "Obstacles", "Loss of direction"],
    uprightMeaning: "Success is yours through sheer willpower, focus, and self-mastery. Harness opposing forces and steer them in a single, unyielding direction toward victory.",
    reversedMeaning: "You are losing your grip on direction, feeling pulled in too many ways, or suffering from uncontrolled aggression and roadblocks. Regroup and recalibrate.",
    description: "A brave warrior drives a chariot drawn by two contrasting black and white sphinxes, moving forward under a canopy of stars.",
    advice: "Stay focused on the finish line. Do not let distractions or minor conflicts throw you off your designated path."
  },
  {
    id: 8,
    name: "Strength",
    number: "VIII",
    iconName: "Activity",
    uprightKeywords: ["Courage", "Inner power", "Patience", "Compassion"],
    reversedKeywords: ["Self-doubt", "Raw emotion", "Weakness", "Insecurity"],
    uprightMeaning: "True power comes not from brute force, but from quiet courage, patience, and gentle persuasion. You can calm any storm and tame any wild situation with compassion.",
    reversedMeaning: "Suggests you are letting fear, self-doubt, or raw, unbridled emotion take the wheel. You may feel weak or inadequate; remember your quiet internal strength.",
    description: "A serene woman crowned with flowers gently and fearlessly closes the jaws of a fierce golden lion under an infinity symbol.",
    advice: "Approach difficulties with soft diplomacy and empathy rather than aggression. Love is the strongest shield you possess."
  },
  {
    id: 9,
    name: "The Hermit",
    number: "IX",
    iconName: "Eye",
    uprightKeywords: ["Soul searching", "Inner guidance", "Solitude", "Wisdom"],
    reversedKeywords: ["Loneliness", "Isolation", "Paranoia", "Withdrawal"],
    uprightMeaning: "A calling to retreat into temporary solitude, seek answers within, and focus on self-discovery. Shine your light inward to illuminate your path.",
    reversedMeaning: "Warning that your solitude is turning into toxic isolation, or that you are refusing to reflect on your actions, drifting into loneliness or paranoia.",
    description: "Standing alone on a snow-capped peak in the dark of night, an elder traveler holds a single lantern containing a six-pointed star.",
    advice: "Unplug from social demands and take a moment of quiet introspection. The noise of others is drowning out your inner light."
  },
  {
    id: 10,
    name: "Wheel of Fortune",
    number: "X",
    iconName: "RefreshCw",
    uprightKeywords: ["Destiny", "Good luck", "Turning point", "Karma"],
    reversedKeywords: ["Bad luck", "Resisting change", "Breaking cycles", "Chaotic forces"],
    uprightMeaning: "Life is constantly moving in cycles. A sudden turn of events, positive luck, or destined encounter is coming. Trust that this shift is aligned with your destiny.",
    reversedMeaning: "Signals an unwelcome change or a series of bad luck that feels out of control. It is a powerful reminder to break old habits and stop resisting inevitable flows.",
    description: "A great bronze wheel inscribed with mysterious letters revolves in the clouds, surrounded by winged mythological figures.",
    advice: "This too shall pass. Whether you are on top of the wheel or at the bottom, remember that change is the only true constant."
  },
  {
    id: 11,
    name: "Justice",
    number: "XI",
    iconName: "Scale",
    uprightKeywords: ["Truth", "Fairness", "Accountability", "Law"],
    reversedKeywords: ["Dishonesty", "Unfairness", "Denial", "Unaccountability"],
    uprightMeaning: "Truth, fairness, and cause-and-effect rule this period. Your past decisions have led to this moment. Justice will prevail, and clarity will be achieved.",
    reversedMeaning: "Indicates bias, unfair treatment, or a refusal to take accountability for your part in a situation. You may be trying to escape consequences.",
    description: "Seated in front of a heavy crimson veil, she holds a double-edged sword upright in one hand and a scale balanced perfectly in the other.",
    advice: "Be completely honest with yourself and others. Own your choices, and act with absolute integrity to maintain harmony."
  },
  {
    id: 12,
    name: "The Hanged Man",
    number: "XII",
    iconName: "Anchor",
    uprightKeywords: ["Pause", "Surrender", "Letting go", "New perspective"],
    reversedKeywords: ["Stalling", "Resistance", "Wasted effort", "Sacrifice"],
    uprightMeaning: "You are being asked to pause, surrender to the present moment, and let go of control. A shift in perspective is occurring, allowing you to see things upside-down.",
    reversedMeaning: "You are resisting the pause, trying to force actions when you should be waiting, or making unnecessary sacrifices that do not lead to growth.",
    description: "Suspended upside-down from a living wooden T-shaped cross by one foot, his face is completely calm, haloed in golden light.",
    advice: "Stop struggling against the current. Surrender to the delay and look at your problems from a completely different angle."
  },
  {
    id: 13,
    name: "Death",
    number: "XIII",
    iconName: "Skull",
    uprightKeywords: ["Endings", "Transformation", "Transition", "Purging"],
    reversedKeywords: ["Resistance to change", "Decay", "Stagnation", "Fear"],
    uprightMeaning: "A major chapter of your life is coming to a natural, inevitable end. This is not physical death, but a powerful transformation to make room for new growth.",
    reversedMeaning: "You are desperately holding on to a dead situation, relationship, or belief. Stagnation is setting in because you fear letting go of the familiar.",
    description: "A skeleton knight in dark armor rides a white horse, bearing a black banner emblazoned with a white mystic rose as the sun sets.",
    advice: "Do not fear endings. Every beautiful sunrise requires the complete death of the night that preceded it."
  },
  {
    id: 14,
    name: "Temperance",
    number: "XIV",
    iconName: "RefreshCw",
    uprightKeywords: ["Balance", "Moderation", "Patience", "Purpose"],
    reversedKeywords: ["Imbalance", "Excess", "Self-healing", "Clashing"],
    uprightMeaning: "A calling to bring balance, moderation, and peaceful alchemy to your life. You are learning to reconcile opposing views and coordinate contrasting forces with patience.",
    reversedMeaning: "Indicates an immediate imbalance, over-indulgence, or clashing coordinates. You are forcing elements together that do not harmoniously merge.",
    description: "A winged celestial being stands with one foot on water and one on land, pouring liquid flows of light between two golden cups.",
    advice: "Practice peaceful compromise. Avoid extreme behaviors and find the comfortable middle ground of your current path."
  },
  {
    id: 15,
    name: "The Devil",
    number: "XV",
    iconName: "Flame",
    uprightKeywords: ["Attachment", "Addiction", "Shadow Self", "Materialism"],
    reversedKeywords: ["Releasing beliefs", "Detachment", "Reclaiming power", "Freedom"],
    uprightMeaning: "Points to self-imposed boundaries, shadow behaviors, and codependent chains. You may be letting immediate physical desires or fears block your higher spiritual path.",
    reversedMeaning: "A powerful trigger of spiritual awakening. You are identifying limiting self-beliefs, breaking codependent loops, and releasing heavy physical attachments.",
    description: "A dark horned figure sits on a black stone pedestal, two figures bound loosely to his base by light iron chains.",
    advice: "Acknowledge your shadow without judgment. You are only as bound as you believe yourself to be; the chains are fully removable."
  },
  {
    id: 16,
    name: "The Tower",
    number: "XVI",
    iconName: "Skull",
    uprightKeywords: ["Sudden Upheaval", "Chaos", "Revelation", "Breakthrough"],
    reversedKeywords: ["Avoiding disaster", "Fear of change", "Stagnation", "Delays"],
    uprightMeaning: "Expect a sudden, unexpected shift or revelation. False foundations are being shattered by a bolt of cosmic lightning to reveal your absolute core truth.",
    reversedMeaning: "You are sensing an inevitable, necessary shift but are desperately trying to delay the collapse, prolonging stagnation at the cost of your evolution.",
    description: "A tall stone tower built on a high peak is struck by golden lightning, its crown-shaped dome displaced amidst clouds of dust.",
    advice: "Do not fight the collapse of things that were built on false pretenses. Let the old wall crumble so you can construct on honest bedrock."
  },
  {
    id: 17,
    name: "The Star",
    number: "XVII",
    iconName: "Sparkles",
    uprightKeywords: ["Hope", "Faith", "Rejuvenation", "Serenity"],
    reversedKeywords: ["Despair", "Lack of faith", "Discouragement", "Insecurity"],
    uprightMeaning: "A period of healing, renewed hope, and divine inspiration is washed over you. The universe is sending comforting blessings, reassuring you that you are protected.",
    reversedMeaning: "You are feeling discouraged, disconnected from your faith, and spiritually exhausted. You may feel like the stars are hidden; they are still shining.",
    description: "Under a giant brilliant eight-pointed star, a naked maiden pours refreshing water onto the soil and into a crystal pool.",
    advice: "Allow yourself to heal. Pour your energy into restorative practices and trust that your hope is fully justified."
  },
  {
    id: 18,
    name: "The Moon",
    number: "XVIII",
    iconName: "MoonStar",
    uprightKeywords: ["Illusion", "Anxiety", "Intuition", "Subconscious"],
    reversedKeywords: ["Release of fear", "Truth revealed", "Clarity", "Deception exposed"],
    uprightMeaning: "Things are not entirely as they seem. Fears, illusions, and anxieties are being projected. Rely on your deepest intuition to guide you through the fog.",
    reversedMeaning: "The fog is lifting, truth is being revealed, and fears are dissolving. You are gaining clarity on a complex, deceptive situation.",
    description: "A path winds between two stone towers under a full glowing moon, with a wild wolf and a dog howling, and a lobster climbing from a pool.",
    advice: "Do not make major physical decisions based on fear or incomplete information. Sleep on it and let your intuition guide you."
  },
  {
    id: 19,
    name: "The Sun",
    number: "XIX",
    iconName: "Sun",
    uprightKeywords: ["Success", "Joy", "Vitality", "Truth"],
    reversedKeywords: ["Temporary sadness", "Clouded joy", "Ego", "Unrealistic outlook"],
    uprightMeaning: "The most positive card in the deck. Abundant joy, incredible vitality, warmth, success, and brilliant clarity are yours. Your light shines brightly for all to see.",
    reversedMeaning: "Your joy is slightly clouded, or you are experiencing temporary setback. You might also be suffering from over-inflated ego or unrealistic expectations.",
    description: "A radiant child rides a white horse through a field of sunflowers, under a massive, glowing, benevolent sun.",
    advice: "Celebrate your wins and spread warmth. Your positive energy is infectious and has the power to heal those around you."
  },
  {
    id: 20,
    name: "Judgement",
    number: "XX",
    iconName: "BookOpen",
    uprightKeywords: ["Awakening", "Reflection", "Reckoning", "Calling"],
    reversedKeywords: ["Self-doubt", "Inner critic", "Ignoring calling", "Stalling"],
    uprightMeaning: "You are experiencing a spiritual calling or personal awakening. Reflect on your choices, integrate your past experiences, and rise to your next octave of evolution.",
    reversedMeaning: "You are hearing the call to transform but are blocking it with excessive self-criticism, over-analysis, or fear of stepping into your true authority.",
    description: "An angelic figure with golden wings sounds a trumpet, as figures rise from stone vaults below, raising their arms in absolute surrender.",
    advice: "Forgive your past mistakes and make a definitive decision. The path of transformation requires you to shed old skin."
  },
  {
    id: 21,
    name: "The World",
    number: "XXI",
    iconName: "Compass",
    uprightKeywords: ["Completion", "Integration", "Achievement", "Travel"],
    reversedKeywords: ["Lack of closure", "Shortcuts", "Unfinished cycles", "Delay"],
    uprightMeaning: "The absolute completion of a major chapter. You have successfully integrated all aspects of this cycle, achieving wisdom, integration, and beautiful personal wholeness.",
    reversedMeaning: "You are nearing a major milestone but are struggling with lack of closure or seeking hasty shortcuts. Do not leave the final loose ends untied.",
    description: "A central figure floats inside a great laurel wreath, surrounded by symbolic representations of the four elements in each corner of the heavens.",
    advice: "Celebrate your journey and tie up all remaining details. You have learned this chapter's lessons; prepare for the next loop."
  }
];

// Generate 56 Minor Arcana programmatically with clearly identified placeholders as requested
const SUITS = [
  { name: "Wands", element: "Fire", icon: "Flame" },
  { name: "Cups", element: "Water", icon: "Heart" },
  { name: "Swords", element: "Air", icon: "Shield" },
  { name: "Pentacles", element: "Earth", icon: "Gem" }
];

const RANKS = [
  "Ace", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten",
  "Page", "Knight", "Queen", "King"
];

const MINOR_ARCANA: TarotCard[] = [];
let idCounter = 22;

SUITS.forEach(suit => {
  RANKS.forEach(rank => {
    MINOR_ARCANA.push({
      id: idCounter++,
      name: `${rank} of ${suit.name}`,
      number: `${rank}`,
      iconName: suit.icon,
      uprightKeywords: ["Minor Arcana Placeholder", suit.name, suit.element],
      reversedKeywords: ["Minor Arcana Placeholder", "Reversed", suit.name],
      uprightMeaning: `[Minor Arcana Placeholder] This structured placeholder represents the ${rank} of ${suit.name} (${suit.element} element) in its upright state. Management coordinates are fully customizable inside the Sanctuary Admin Panel.`,
      reversedMeaning: `[Minor Arcana Placeholder] This structured placeholder represents the ${rank} of ${suit.name} (${suit.element} element) in its reversed state. Management coordinates are fully customizable inside the Sanctuary Admin Panel.`,
      description: `A template representing the ${rank} of ${suit.name} in the suite of ${suit.name}.`,
      advice: `Examine how the energy of ${suit.element} applies to your present query.`
    });
  });
});

export const TAROT_DECK: TarotCard[] = [...MAJOR_ARCANA, ...MINOR_ARCANA];

export const ZODIAC_SIGNS: ZodiacSign[] = [
  {
    id: "aries",
    name: "Aries",
    symbol: "♈",
    dateRange: "Mar 21 – Apr 19",
    element: "Fire",
    rulingPlanet: "Mars",
    traits: ["Courageous", "Determined", "Confident", "Enthusiastic"],
    compatibility: "Leo, Sagittarius",
    luckyColor: "Crimson Red",
    horoscope: {
      general: "The celestial currents are igniting your passion today. A cosmic alignment with Mars gives you an extra burst of willpower, perfect for initiating bold projects that you've been delaying.",
      love: "Open communication will break an unspoken barrier today. Be direct but gentle with your heart's desires.",
      career: "A leadership position is opening up. Stand tall and let your unique problem-solving capabilities shine.",
      luckyNumber: 9,
      luckyTime: "10:30 AM",
      mood: "Unstoppable"
    }
  },
  {
    id: "taurus",
    name: "Taurus",
    symbol: "♉",
    dateRange: "Apr 20 – May 20",
    element: "Earth",
    rulingPlanet: "Venus",
    traits: ["Reliable", "Patient", "Practical", "Devoted"],
    compatibility: "Virgo, Capricorn",
    luckyColor: "Emerald Green",
    horoscope: {
      general: "Venus is shining a nurturing light on your domestic sector today. Focus on grounding yourself in nature, organizing your space, and celebrating the physical comforts that bring you peace.",
      love: "Sensual pleasures and stable, comforting presence are favored. Plan a quiet, luxurious night with your favorite meals.",
      career: "A slow, deliberate financial decision made today will yield incredible compounding benefits down the line.",
      luckyNumber: 6,
      luckyTime: "2:15 PM",
      mood: "Grounded"
    }
  },
  {
    id: "gemini",
    name: "Gemini",
    symbol: "♊",
    dateRange: "May 21 – Jun 20",
    element: "Air",
    rulingPlanet: "Mercury",
    traits: ["Adaptable", "Outgoing", "Intellectual", "Inquisitive"],
    compatibility: "Libra, Aquarius",
    luckyColor: "Saffron Yellow",
    horoscope: {
      general: "Your intellectual curiosity is running at an all-time high today. Conversations flow seamlessly, making it an incredible time to network, pitch ideas, or dive into deep esoteric research.",
      love: "Laughter and deep mental connection are your love language today. Share a quirky theory with someone special.",
      career: "Multitasking comes naturally today, but focus on completing one major project before starting three new ones.",
      luckyNumber: 5,
      luckyTime: "4:40 PM",
      mood: "Sparkling"
    }
  },
  {
    id: "cancer",
    name: "Cancer",
    symbol: "♋",
    dateRange: "Jun 21 – Jul 22",
    element: "Water",
    rulingPlanet: "Moon",
    traits: ["Intuitive", "Protective", "Sentimental", "Empathetic"],
    compatibility: "Scorpio, Pisces",
    luckyColor: "Silver Pearl",
    horoscope: {
      general: "The Moon is highly active in your sign, heightening your empathy and psychic receptivity. You can feel the underlying emotional layers of any room. Use this gift to heal yourself and others.",
      love: "Vulnerability is your superpower today. Share a memory or a soft secret with a partner to deepen the bond.",
      career: "Trust your gut instincts over spreadsheets today when negotiating or evaluating a prospective partner.",
      luckyNumber: 2,
      luckyTime: "9:15 PM",
      mood: "Intuitively Deep"
    }
  },
  {
    id: "leo",
    name: "Leo",
    symbol: "♌",
    dateRange: "Jul 23 – Aug 22",
    element: "Fire",
    rulingPlanet: "Sun",
    traits: ["Generous", "Warmhearted", "Charismatic", "Loyal"],
    compatibility: "Aries, Sagittarius",
    luckyColor: "Warm Gold",
    horoscope: {
      general: "Your ruling celestial body, the Sun, is radiating directly into your aura. People are naturally drawn to your warmth and charisma. Use this beautiful spotlight to inspire, create, and lead.",
      love: "Grand romantic gestures or expressing bold appreciation will create a lasting, joyful memory today.",
      career: "Your creative portfolio is under review. Highlight your unique signature stamp; do not try to blend in.",
      luckyNumber: 1,
      luckyTime: "12:00 PM",
      mood: "Radiant"
    }
  },
  {
    id: "virgo",
    name: "Virgo",
    symbol: "♍",
    dateRange: "Aug 23 – Sep 22",
    element: "Earth",
    rulingPlanet: "Mercury",
    traits: ["Analytical", "Hardworking", "Kind", "Practical"],
    compatibility: "Taurus, Capricorn",
    luckyColor: "Deep Navy Blue",
    horoscope: {
      general: "A beautiful alignment in your sector of order invites you to declutter your mind and environment. You can see the exact steps required to solve a complex puzzle that has frustrated others.",
      love: "Acts of service and practical help are your best expressions of care today. Help a loved one organize a burden.",
      career: "Your precision and attention to detail are spotted by superiors. A subtle promotion or recognition is imminent.",
      luckyNumber: 3,
      luckyTime: "8:00 AM",
      mood: "Razor Sharp"
    }
  },
  {
    id: "libra",
    name: "Libra",
    symbol: "♎",
    dateRange: "Sep 23 – Oct 22",
    element: "Air",
    rulingPlanet: "Venus",
    traits: ["Harmonious", "Diplomatic", "Artistic", "Gracious"],
    compatibility: "Gemini, Aquarius",
    luckyColor: "Soft Turquoise",
    horoscope: {
      general: "Cosmic balances are shifting in your favor today. You are a natural mediator, and your ability to bring harmony to chaotic spaces is highly requested. Surround yourself with art and beautiful music.",
      love: "A beautiful day for equal partnership. Balance the scales of give-and-take to restore absolute peace.",
      career: "Negotiations or signing cooperative contracts are highly favored. Everyone leaves satisfied with your mediation.",
      luckyNumber: 7,
      luckyTime: "5:30 PM",
      mood: "Harmonious"
    }
  },
  {
    id: "scorpio",
    name: "Scorpio",
    symbol: "♏",
    dateRange: "Oct 23 – Nov 21",
    element: "Water",
    rulingPlanet: "Pluto",
    traits: ["Passionate", "Resourceful", "Brave", "Mysterious"],
    compatibility: "Cancer, Pisces",
    luckyColor: "Midnight Obsidian",
    horoscope: {
      general: "Pluto is stirring deep transformations inside you. It is a day of profound psychological breakthrough. Let go of old control patterns to allow new spiritual power to emerge.",
      love: "Intense, soulful connections are highlighted. Superficial talk won't work; you need deep, unfiltered intimacy.",
      career: "An investigation or deep research project yields a critical hidden variable. Trust what is written between the lines.",
      luckyNumber: 8,
      luckyTime: "11:11 PM",
      mood: "Transformative"
    }
  },
  {
    id: "sagittarius",
    name: "Sagittarius",
    symbol: "♐",
    dateRange: "Nov 22 – Dec 21",
    element: "Fire",
    rulingPlanet: "Jupiter",
    traits: ["Generous", "Idealistic", "Philosophical", "Humorous"],
    compatibility: "Aries, Leo",
    luckyColor: "Royal Amethyst",
    horoscope: {
      general: "Jupiter, the planet of expansion, is expanding your boundaries today. Your mind is focused on the horizon—new travels, philosophical ideas, and spiritual systems are beckoning you forward.",
      love: "Adventure awaits! Try something brand new with a partner, or travel to an unexplored area to spark excitement.",
      career: "A bold, calculated risk pays off. Your optimism is a powerful magnet for lucky financial breaks today.",
      luckyNumber: 4,
      luckyTime: "3:15 PM",
      mood: "Adventurous"
    }
  },
  {
    id: "capricorn",
    name: "Capricorn",
    symbol: "♑",
    dateRange: "Dec 22 – Jan 19",
    element: "Earth",
    rulingPlanet: "Saturn",
    traits: ["Responsible", "Disciplined", "Patient", "Ambitious"],
    compatibility: "Taurus, Virgo",
    luckyColor: "Charcoal Bronze",
    horoscope: {
      general: "Saturn is strengthening your discipline and determination. You are building lasting foundations, and the steady, tireless effort you put in today will secure your status for years to come.",
      love: "Showing reliability and long-term commitment matters most. A solid promise counts more than fancy words.",
      career: "A long-term project is reaching a major milestone. Keep your head down and finish strong; the reward is secure.",
      luckyNumber: 10,
      luckyTime: "9:00 AM",
      mood: "Relentless"
    }
  },
  {
    id: "aquarius",
    name: "Aquarius",
    symbol: "♒",
    dateRange: "Jan 20 – Feb 18",
    element: "Air",
    rulingPlanet: "Uranus",
    traits: ["Progressive", "Original", "Independent", "Humanitarian"],
    compatibility: "Gemini, Libra",
    luckyColor: "Electric Turquoise",
    horoscope: {
      general: "Uranus is sparking flash-of-insight visions in your mind. You are thinking outside the collective box, channeling futuristic solutions for humanitarian issues or complex community problems.",
      love: "Embrace your eccentricities and unique style. The right person will love your quirky spiritual views.",
      career: "Collaborative teamwork and digital brainstorming are highly favored. Your modern perspective leads the way.",
      luckyNumber: 11,
      luckyTime: "6:15 PM",
      mood: "Inspired"
    }
  },
  {
    id: "pisces",
    name: "Pisces",
    symbol: "♓",
    dateRange: "Feb 19 – Mar 20",
    element: "Water",
    rulingPlanet: "Neptune",
    traits: ["Compassionate", "Artistic", "Intuitive", "Wise"],
    compatibility: "Cancer, Scorpio",
    luckyColor: "Ocean Teal",
    horoscope: {
      general: "Neptune is dissolving the barrier between your physical reality and spiritual realms. Your dreams are prophetic, your creative energy is limitless, and your compassion knows no bounds today.",
      love: "A dreamy, ethereal soulmate connection is in the air. Let yourself drift in the beautiful flow of love.",
      career: "Your artistic, visual, or healing talents are highly effective. Channel your dreams directly into your work.",
      luckyNumber: 7,
      luckyTime: "11:11 AM",
      mood: "Dreamy & Prophetic"
    }
  }
];

export const NUMEROLOGY_PROFILES: Record<number, NumerologyProfile> = {
  1: {
    number: 1,
    title: "The Pioneer Leader",
    tagline: "Independence, innovation, and starting new paths.",
    personality: "You are a natural-born leader, fiercely independent, and brimming with original ideas. You possess an unyielding drive to be the first and the best in your chosen endeavors.",
    strengths: ["Courageous", "Innovative", "Strong-willed", "Self-motivated"],
    weaknesses: ["Impatient", "Self-centered", "Aggressive", "Fear of failure"],
    careerPaths: ["Entrepreneur", "Executive", "Creative Director", "Inventor"],
    compatibility: "3, 5, 7"
  },
  2: {
    number: 2,
    title: "The Harmonic Peacekeeper",
    tagline: "Diplomacy, cooperation, and intuitive sensitivity.",
    personality: "You are the ultimate supportive partner, diplomat, and mediator. Your strength lies in intuition, empathy, and your gentle ability to bring people together in complete harmony.",
    strengths: ["Empathetic", "Diplomatic", "Patient", "Intuitive"],
    weaknesses: ["Overly sensitive", "Codependent", "Passive-aggressive", "Indecisive"],
    careerPaths: ["Mediator", "Counselor", "Artist", "Diplomat"],
    compatibility: "4, 6, 8"
  },
  3: {
    number: 3,
    title: "The Creative Communicator",
    tagline: "Self-expression, artistic genius, and joy of life.",
    personality: "You are a radiant source of joy, humor, and creative self-expression. You find meaning in art, writing, performing, or inspiring others with your sparkling conversational charisma.",
    strengths: ["Expressive", "Optimistic", "Imaginative", "Charismatic"],
    weaknesses: ["Unfocused", "Superficial", "Gossipy", "Anxious"],
    careerPaths: ["Writer", "Actor", "Marketing Expert", "Public Speaker"],
    compatibility: "1, 5, 9"
  },
  4: {
    number: 4,
    title: "The Master Builder",
    tagline: "Stability, structure, hard work, and loyalty.",
    personality: "You are the rock of society. Practical, disciplined, and incredibly reliable, you specialize in taking chaotic ideas and building stable, structured systems that last for generations.",
    strengths: ["Organized", "Loyal", "Practical", "Extremely disciplined"],
    weaknesses: ["Rigid", "Stubborn", "Overly cautious", "Workaholic"],
    careerPaths: ["Architect", "Financial Planner", "Project Manager", "Engineer"],
    compatibility: "2, 6, 8"
  },
  5: {
    number: 5,
    title: "The Free Spirit Adventurer",
    tagline: "Freedom, adaptability, travel, and sensory curiosity.",
    personality: "You crave absolute freedom, variety, and adventure. You are a versatile explorer who learns through direct sensory experience, constant change, and meeting diverse cultures.",
    strengths: ["Adaptable", "Adventurous", "Charismatic", "Curious"],
    weaknesses: ["Restless", "Impulsive", "Inconsistent", "Indulgent"],
    careerPaths: ["Travel Writer", "Sales Director", "Event Planner", "Public Relations"],
    compatibility: "1, 3, 7"
  },
  6: {
    number: 6,
    title: "The Divine Nurturer",
    tagline: "Responsibility, healing, unconditional love, and service.",
    personality: "You carry a powerful vibration of love, home, and community service. You are the ultimate caregiver, healer, and protector, finding purpose in bringing comfort to suffering souls.",
    strengths: ["Compassionate", "Responsible", "Protective", "Natural healer"],
    weaknesses: ["Intrusive", "Self-sacrificing", "Perfectionist", "Guilt-ridden"],
    careerPaths: ["Doctor/Nurse", "Teacher", "Social Worker", "Interior Designer"],
    compatibility: "2, 4, 9"
  },
  7: {
    number: 7,
    title: "The Sacred Seeker",
    tagline: "Analysis, spirituality, wisdom, and solitude.",
    personality: "You are a spiritual detective and truth-seeker. You live inside your mind and spirit, possessing an exceptional intellect combined with a natural gift for deep esoteric mysteries.",
    strengths: ["Analytical", "Philosophical", "Intuitive", "Independent"],
    weaknesses: ["Secretive", "Cold", "Skeptical", "Socially isolated"],
    careerPaths: ["Researcher", "Astronomer", "Spiritual Mentor", "Analyst"],
    compatibility: "1, 5, 9"
  },
  8: {
    number: 8,
    title: "The Manifestation Powerhouse",
    tagline: "Abundance, business power, authority, and karma.",
    personality: "You are a force of worldly achievement, material abundance, and administrative mastery. You understand how the laws of cause-and-effect govern physical and financial success.",
    strengths: ["Ambitious", "Efficient", "Strong leader", "Abundant manifestation"],
    weaknesses: ["Materialistic", "Overbearing", "Authoritarian", "Impulsive"],
    careerPaths: ["CEO", "Financial Advisor", "Real Estate Mogul", "Lawyer"],
    compatibility: "2, 4, 6"
  },
  9: {
    number: 9,
    title: "The Universal Humanitarian",
    tagline: "Compassion, global vision, completion, and healing.",
    personality: "You are a soulful, wise humanitarian who loves all of humanity. You have reached a stage of spiritual completion, ready to offer selfless service, artistic genius, and healing to the world.",
    strengths: ["Altruistic", "Generous", "Artistic", "Globally minded"],
    weaknesses: ["Vague", "Moody", "Prone to martyr complex", "Struggles with letting go"],
    careerPaths: ["Philanthropist", "Artist/Musician", "Spiritual Teacher", "Environmentalist"],
    compatibility: "3, 6, 7"
  },
  11: {
    number: 11,
    title: "The Master Intuitive Messenger (11)",
    tagline: "Divine illumination, spiritual insight, and charisma.",
    personality: "A Master Number. You are a bridge between physical realms and spiritual planes, holding intense intuitive radar, prophetic vision, and a magnetic charisma meant to illuminate humanity.",
    strengths: ["Highly intuitive", "Idealistic", "Charismatic", "Spiritual pioneer"],
    weaknesses: ["High nervous energy", "Extremely sensitive", "Prone to anxiety", "Self-doubt"],
    careerPaths: ["Spiritual Channel", "Motivational Speaker", "Creative Visionary", "Psychic"],
    compatibility: "2, 7, 9"
  },
  22: {
    number: 22,
    title: "The Master Builder Architect (22)",
    tagline: "Turning huge cosmic dreams into physical reality.",
    personality: "A Master Number. You possess the spiritual vision of the 11 combined with the practical discipline of the 4, enabling you to manifest grand humanitarian dreams on a global scale.",
    strengths: ["Practical visionary", "Natural organizer", "Extremely capable", "Ambitious"],
    weaknesses: ["Rigorous self-pressure", "Fear of failure", "Control issues", "Overworked"],
    careerPaths: ["Global Planner", "Real Estate Developer", "Philosophical Architect", "Founder"],
    compatibility: "4, 8, 11"
  }
};

export const CHAT_TEMPLATES = [
  { sender: "AuraSeeker", text: "Is there a specific card indicating a career shift soon?", role: "viewer" },
  { sender: "Seraphina_Mystic", text: "Wow, the energy in this room is incredible! ✨", role: "viewer" },
  { sender: "Luna_Phase", text: "Can you consult cards for my love life? Scorpio here!", role: "viewer" },
  { sender: "SolarEclipse", text: "Just sent a Cosmic Lotus! Thank you for the guidance 🌸", role: "viewer" },
  { sender: "ZenTraveler", text: "My Life Path is 7, matches the Hermit perfectly!", role: "viewer" },
  { sender: "CosmicSage", text: "Do reversed cards always mean negative energy or just slow growth?", role: "viewer" },
  { sender: "EarthStar", text: "I feel so grounded listening to this reading.", role: "viewer" },
  { sender: "CrystalLover", text: "Just got my daily Tarot. The Star upright! So happy 🌟", role: "viewer" },
  { sender: "NebulaQueen", text: "Beautiful gold deck you have there!", role: "viewer" }
];

export const GIFT_TEMPLATES = [
  { id: "quartz", name: "Crystal Quartz", cost: 5, icon: "💎", color: "from-blue-400 to-purple-400" },
  { id: "lotus", name: "Golden Lotus", cost: 20, icon: "🪷", color: "from-amber-300 to-yellow-500" },
  { id: "chalice", name: "Cosmic Chalice", cost: 50, icon: "🏆", color: "from-cyan-400 to-teal-400" },
  { id: "feather", name: "Phoenix Feather", cost: 100, icon: "🪶", color: "from-red-500 to-amber-500" },
  { id: "star", name: "Cosmic Star Sphere", cost: 200, icon: "✨", color: "from-purple-500 to-pink-500" }
];
